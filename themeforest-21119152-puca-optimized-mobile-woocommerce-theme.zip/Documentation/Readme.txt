Hello dear customers :)

We thank you for purchasing our theme. Hope our theme will be of great help for you to succeed. We appreciate your decision to read the manual before the request for our support.

Please refer to our support systems:
- Facebook: https://www.facebook.com/thembayteam/
- Ticket System: https://tickets.thembay.com/
- Video Tutorials: https://www.youtube.com/c/thembay						

