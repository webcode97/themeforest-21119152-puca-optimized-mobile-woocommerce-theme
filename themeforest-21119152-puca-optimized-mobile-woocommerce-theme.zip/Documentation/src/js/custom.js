function document_lazyload() {
	jQuery('.lazy:visible').Lazy({
		 afterLoad: function(element) {
			element.addClass('loaded');
		},
	 });	 
}
jQuery(window).on("load", function(){
	document_lazyload();
	
});	

jQuery(document).ready(function(){
	
	
	jQuery('#mmenu').mmenu({
		extensions	: [ 'theme-dark' ],
		setSelected	: true,
		counters	: true,
		searchfield : {
			placeholder		: 'Search menu items'
		},
		iconbar		: {
			add 		: true,
			size		: 40,
			top 		: [ 
				'<a href="#mm-0"><i class="fas fa-bars"></i></a>'
			],
			bottom 		: [
				'<a target="_blank"  href="https://www.facebook.com/thembayteam/"><i class="fab fa-facebook-square"></i></a>',
				'<a target="_blank"  href="https://twitter.com/bay_them"><i class="fab fa-twitter-square"></i></a>',
				'<a target="_blank"  href="https://www.youtube.com/c/thembay"><i class="fab fa-youtube-square"></i></a>'
			]
		},
		sidebar		: {
			collapsed		: {
				use 			: '(min-width: 320px)',
				size			: 35,
				hideNavbar		: false
			},
			expanded		: {
				use 			: '(min-width: 992px)',
				size			: 35
			}
		},
		navbars		: [
			{
				content		: [ 'searchfield' ]
			}, {
				type		: 'tabs',
				content		: [ 
					'<a href="#docs_navigation"><i class="fa fa-bars"></i> <span>Menu</span></a>', 
					'<a class="hide-mobile" href="#panel-ticket"><i class="far fa-life-ring"></i> <span>Support</span></a>', 
					'<a class="hide-mobile" href="#panel-cart"><i class="fas fa-shopping-cart"></i> <span>Purchase</span></a>'
				]
			}, {
				position	: 'bottom',
				content		: [ '<p><span class="version">Version 2.6.5</span> Last Update : February 08, 2023</p>' ]
			}
		]
	}, {
		searchfield : {
			clear 		: true
		},
		navbars		: {
			breadcrumbs	: {
				removeFirst	: true
			}
		}
	});
	
	document_lazyload();
	
	jQuery("#puca-load").fadeOut();
	
	if(window.location.href.indexOf("#") > -1) {
		var linkcuren 		= window.location.href;
		var numbercuren 	= linkcuren.search("#");
		var divcuren 		= window.location.href.slice(numbercuren);
		
		jQuery(".vg-content").css('display','none');
		jQuery(divcuren).css('display','block');
		jQuery(divcuren).parent().parent( '.vg-content').css('display','block');
		
		jQuery(".bs-sidebar1 > ul > li").removeClass("active");
		jQuery(".bs-sidebar1>ul>li>a[href$='" + divcuren + "']").parent().addClass("active");
		
	}
	
	jQuery(".bs-sidebar1 > ul > li > a.scrollto").click(function(event) {
		jQuery(".vg-content").css('display','none');
		jQuery(jQuery(this).attr('href')).css('display','block');
		jQuery(".bs-sidebar1 > ul > li").removeClass("active");
		jQuery(this).parent().addClass("active");
		
		document_lazyload();
	});
	
	jQuery(".bs-sidebar1 > ul > li > a.mm-btn").click(function(event) {
		jQuery(".vg-content").css('display','none');
		jQuery(jQuery(this).parent().children(".scrollto").attr('href')).css('display','block');
		jQuery(".bs-sidebar1 > ul > li").removeClass("active");
		jQuery(this).parent().addClass("active");
		
		document_lazyload();
	});
	
	
	jQuery(".mm-panel_has-navbar > ul > li > a").click(function(event) {
		jQuery(".mm-panel_has-navbar > ul > li").removeClass("active");
		jQuery(this).parent().addClass("active");
		document_lazyload();
	});
	jQuery(".mm-listitem a").click(function(event) {
		document_lazyload();
	});
	
	jQuery(".bs-sidebar1  ul ul > li > a").click(function(event) {
		jQuery(".vg-content").css('display','none');
		jQuery(jQuery(this).parent().parent().parent().children(".pa").attr('href')).css('display','block');
		jQuery(".bs-sidebar1 > ul > li").removeClass("active");
		jQuery(this).parent().parent().parent().addClass("active");
		document_lazyload();
		
	});
	
	
	
	jQuery('.bs-sidebar1 ul > li > a').onePageNav({
		currentClass: 'active1',
		changeHash: false,
		scrollSpeed: 800
	});
	
	jQuery('.mm-panel_has-navbar > ul > li > a').onePageNav({
		currentClass: 'active1',
		changeHash: false,
		scrollSpeed: 800
	});

	// Scrolling
	jQuery('a.scrollto').click(function() {
		if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
			var target = jQuery(this.hash);
			target = target.length ? target : jQuery("[name='" + this.hash.slice(1) +"']");
			if (target.length) {
				jQuery('#wrapper').removeClass('behind');
				jQuery('.mobile-nav').removeClass('active1');
				jQuery('html,body').animate({
					scrollTop: target.offset().top
				}, 1000);
				return false;
			}
		}
	});	

	
});

